# SMS Gateway Starter

Manual SMS test prototype. Not connected to Firebase and does not expose an HTTP API or automatic OTP queue.

## GitHub upload instructions (mobile)
1. Download and extract this ZIP.
2. Open your GitHub repository's **Add file > Upload files** page.
3. Upload the *contents* of the extracted folder, not the ZIP itself. Keep the folder paths exactly as shown.
4. Confirm the repository root contains `settings.gradle.kts`, `build.gradle.kts`, `gradle.properties`, `app/`, and `.github/workflows/build-apk.yml`.
5. Commit changes.
6. Open **Actions > Build SMS Gateway APK > Run workflow**. Wait for a successful run.
7. Download the `SmsGateway-debug-apk` artifact, extract it, and install `app-debug.apk`.

This is a debug APK. Android SMS permission, active SIM, network and carrier support are required. SMS delivery is not guaranteed. Use only with recipients who have consented. Google Play restricts SMS permissions. Do not use for unsolicited or bulk messaging.
